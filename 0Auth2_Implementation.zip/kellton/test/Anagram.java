//**********************************************************************
// Copyright (c) 2020 Telefonaktiebolaget LM Ericsson, Sweden.
// All rights reserved.
// The Copyright to the computer program(s) herein is the property of
// Telefonaktiebolaget LM Ericsson, Sweden.
// The program(s) may be used and/or copied with the written permission
// from Telefonaktiebolaget LM Ericsson or in accordance with the terms
// and conditions stipulated in the agreement/contract under which the
// program(s) have been supplied.
// **********************************************************************
package com.kellton.test;

public class Anagram
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        System.out.println(is_anagram("cellar", "recall"));
        System.out.println(is_anagram("arm", "elbow"));

    }

    private static boolean is_anagram(String str1, String str2)
    {
        if (str1.length() != str2.length())
        {
            return false;
        }
        else if (str1.equals(str2))
        {
            return true;
        }
        char[] firstArr = str1.toLowerCase().toCharArray();
        char[] secondArr = str2.toLowerCase().toCharArray();

        int[] count = new int[26];
        for (int i = 0; i < firstArr.length; i++)
        {
            count[firstArr[i] - 97]++;
            count[secondArr[i] - 97]--;
        }

        for (int i = 0; i < 26; i++)
        {
            if (count[i] != 0)
            {
                return false;
            }
        }
        return true;
    }
}
