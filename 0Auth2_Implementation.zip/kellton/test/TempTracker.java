//**********************************************************************
// Copyright (c) 2020 Telefonaktiebolaget LM Ericsson, Sweden.
// All rights reserved.
// The Copyright to the computer program(s) herein is the property of
// Telefonaktiebolaget LM Ericsson, Sweden.
// The program(s) may be used and/or copied with the written permission
// from Telefonaktiebolaget LM Ericsson or in accordance with the terms
// and conditions stipulated in the agreement/contract under which the
// program(s) have been supplied.
// **********************************************************************
package com.kellton.test;

public class TempTracker
{

    private int total_numbers = 0;
    private int max_occurance = 0;
    private final int[] occurance = new int[150];
    private float mean = 0.0f;
    private int mode = 0;
    private float total_sum = 0.0f;
    private int min = 150;
    private int max = -1;

    /**
     * @return the mean
     */
    public float getMean()
    {
        return mean;
    }

    /**
     * @return the mode
     */
    public int getMode()
    {
        return mode;
    }

    /**
     * @return the min
     */
    public int getMin()
    {
        return min;
    }

    /**
     * @return the max
     */
    public int getMax()
    {
        return max;
    }

    public void insert(int temperature) throws Exception
    {
        if (temperature < 0 || temperature > 150)
        {
            throw new Exception("Number should be in range of 1 to 150");
        }

        occurance[temperature]++;
        total_numbers++;

        if (temperature < min)
        {
            min = temperature;
        }

        if (temperature > max)
        {
            max = temperature;
        }

        total_sum += temperature;

        mean = total_sum / (total_numbers);

        if (occurance[temperature] > max_occurance)
        {
            max_occurance = occurance[temperature];
        }

        mode = temperature;
    }

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception
    {
        // TODO Auto-generated method stub
        TempTracker tracker = new TempTracker();
        tracker.insert(10);
        tracker.insert(4);
        tracker.insert(2);
        tracker.insert(120);
        tracker.insert(100);
        tracker.insert(50);
        tracker.insert(20);
        tracker.insert(40);

        System.out.println(tracker.getMax());
        System.out.println(tracker.getMin());
        System.out.println(tracker.getMean());
        System.out.println(tracker.getMode());

    }
}
